# -*- coding: utf-8 -*-
"""
desertification.config
======================
All constants, hyperparameters, variable maps, and metadata.

Merged from:
  - V6 Cell 24: vars_map (with agg field), CEIL_CONFIG (gradient drift_base),
    PYSR constants, EQ_BOUNDS, SIGN_CHANGE_RANGE
  - V5 Cell 23: VARIABLE_META (with rich descriptions), K_REGION,
    CEIL_CONFIG (region-specific ndvi_points)
  - V3 Cell 20: FIX-A through FIX-P constants

Cumulative fix provenance
-------------------------
FIX-A   Aridity_safe replaces raw Aridity_Index (div-by-zero spikes)
FIX-B   Drift magnitude guard DRIFT_CLIP
FIX-C   Slope check at equilibrium
FIX-D   Multi-driver preference within priority tiers
FIX-E   Lyapunov sanity check |λ| > 10
FIX-F   Post-run lever effectiveness audit
FIX-G   Per-feature pre-PySR audit
FIX-H   feature_audit NDVI self-corr crash fix
FIX-I   No-sign-change ODE rejection all tiers
FIX-J   Slope threshold tightened 5 → 2
FIX-K   Drift clip relaxed 0.30 → 0.40
FIX-L   PySR hyperparameters tuned
FIX-M   Nested-trig rejection
FIX-N   Auto-correct inverted lever signs
FIX-O   SDE burn-in drift damping (2 yr ramp)
FIX-P   Evapo mode threshold 0.40 → 0.30
FIX-Q   Drop LOW-CORR features per-region
FIX-R   P4 requires sign-change; P5 = fallback
FIX-S   Per-region PySR iterations
FIX-T   IQR ribbon (p25–p75) vs p10–p90
FIX-U   Per-region eq bounds and slope
FIX-V   Synthetic ceiling augmentation
FIX-W   Per-region sign-change scan range
FIX-X   has_stable_sign_change() + P2.5 priority tier
FIX-Y   NDVI_logistic feature + carrying capacity K
FIX-Z   Region-specific ceiling augmentation (CEIL_CONFIG)
FIX-AA  Physical direction metadata + derived variable protection
FIX-AB  K-modulating SDE for attractor-shifting interventions
FIX-AC  Phase portrait panel
FIX-AD  Deseasonalise dNDVI/dt training target
FIX-AE  Post-hoc NDVI_logistic injection when NDVI absent
FIX-AF  Gradient ceiling rows
FIX-AG  NDVI_logistic removed from PySR features
FIX-AH  PySR ^ constraint removed
"""

# ============================================================
# GEE Variable Map
# ============================================================
# Each entry defines: GEE dataset ID, band name, spatial resolution,
# and aggregation method (sum for precipitation, median for everything else).

vars_map = {
    # Vegetation
    'NDVI':      {'id': "MODIS/061/MOD13Q1",             'band': 'NDVI',                'res': 500,   'agg': 'median'},
    'EVI':       {'id': "MODIS/061/MOD13Q1",             'band': 'EVI',                 'res': 500,   'agg': 'median'},
    'LAI':       {'id': "MODIS/061/MCD15A3H",            'band': 'Lai',                 'res': 500,   'agg': 'median'},
    'FPAR':      {'id': "MODIS/061/MCD15A3H",            'band': 'Fpar',                'res': 500,   'agg': 'median'},
    # Carbon
    'GPP':       {'id': "MODIS/061/MOD17A2H",            'band': 'Gpp',                 'res': 500,   'agg': 'median'},
    # Temperature
    'LST_Day':   {'id': "MODIS/061/MOD11A2",             'band': 'LST_Day_1km',         'res': 1000,  'agg': 'median'},
    'LST_Night': {'id': "MODIS/061/MOD11A2",             'band': 'LST_Night_1km',       'res': 1000,  'agg': 'median'},
    # Water
    'Rain':      {'id': "UCSB-CHG/CHIRPS/DAILY",         'band': 'precipitation',       'res': 5000,  'agg': 'sum'},
    'SoilMoist': {'id': "NASA/FLDAS/NOAH01/C/GL/M/V001", 'band': 'SoilMoi00_10cm_tavg', 'res': 10000, 'agg': 'median'},
    'Evapo':     {'id': "MODIS/061/MOD16A2",             'band': 'ET',                  'res': 500,   'agg': 'median'},
    # Surface reflectance
    'Albedo':    {'id': "MODIS/061/MCD43A3",             'band': 'Albedo_WSA_shortwave', 'res': 500,  'agg': 'median'},
    # Disturbance
    'Fire':      {'id': "MODIS/061/MCD64A1",             'band': 'BurnDate',            'res': 500,   'agg': 'median'},
    # Atmosphere
    'AOD':       {'id': "MODIS/061/MCD19A2_GRANULES",    'band': 'Optical_Depth_055',   'res': 1000,  'agg': 'median'},
}

# ============================================================
# Per-Region Carrying Capacity
# ============================================================
# Empirical 95th-percentile NDVI. Rajasthan canal-irrigated fields
# peak near 0.60–0.65; Gobi steppe rarely exceeds 0.20–0.25.
K_REGION = {
    'Rajasthan Canal': 0.65,
    'Gobi Green Wall': 0.25,
}

# ============================================================
# PySR Hyperparameters  (FIX-L, FIX-S, FIX-AH)
# ============================================================
NITER_RAJ  = 260   # FIX-S: deeper Rajasthan search to reduce run-to-run weak-fit outliers
NITER_GOBI = 240

PYSR_BINARY_OPS  = ["+", "*", "-", "/"]
# Rajasthan often converges to denominator-heavy anomaly equations that are
# numerically brittle. This operator set is used as a safer fallback search mode.
PYSR_BINARY_OPS_NO_DIV = ["+", "*", "-"]
PYSR_UNARY_OPS   = ["exp", "sin", "cos"]
PYSR_MAXSIZE     = 12   # FIX-L: prefer simpler, more interpretable equations
PYSR_POPULATIONS = 30   # FIX-L

# Near-zero anomaly features invite reciprocal expressions (1/x) and produce
# singular drift surfaces. For Rajasthan we prune these before PySR search.
RAJASTHAN_DENOM_PRONE_FEATURES = (
  'LST_Day_anom',
  'Temp_Delta_anom',
)

# FIX-BA: Per-region feature exclusions based on data quality.
# Rajasthan has extremely low NDVI (0.2-0.55), making NDVI_sq near-zero variance.
# Carbon_Flux, GPP, Fire_Pressure are dead/sparse signals for Rajasthan (almost all zeros).
FEATURES_TO_EXCLUDE_BY_REGION = {
    'Rajasthan Canal': {'NDVI_sq', 'Carbon_Flux', 'GPP', 'Fire_Pressure'},
    'Gobi Green Wall': set(),  # No exclusions for Gobi
}

# ============================================================
# Drift & Equilibrium Constants  (FIX-K, FIX-J, FIX-U, FIX-W)
# ============================================================
DRIFT_CLIP = 0.40   # FIX-K: drift magnitude guard

# FIX-U: per-region equilibrium parameters
EQ_SLOPE_RAJ   = 3.0
EQ_SLOPE_GOBI  = 2.0
EQ_BOUNDS_RAJ  = (0.08, 0.95)
EQ_BOUNDS_GOBI = (0.05, 0.90)

# FIX-W: per-region ecologically observed NDVI range for sign-change detection
SIGN_CHANGE_RANGE_RAJ  = (0.10, 0.80)
SIGN_CHANGE_RANGE_GOBI = (0.05, 0.25)

# ============================================================
# Ceiling Augmentation Config  (FIX-Z, FIX-AF)
# ============================================================
# Region-specific ceiling augmentation. ndvi_points are just beyond each
# region's 95th-percentile NDVI. drift_base uses gradient scaling (FIX-AF):
#   drift_c = drift_base * (ndvi_c / ndvi_max_ceil)
# This prevents a constant-output ODE from satisfying the ceiling constraint.
# Weight is the number of synthetic copies per point.
CEIL_CONFIG = {
    'Rajasthan Canal': {'ndvi_points': [0.62, 0.66, 0.70, 0.74, 0.78], 'drift_base': -0.035, 'weight': 5},
    'Gobi Green Wall': {'ndvi_points': [0.21, 0.23, 0.25, 0.27, 0.29], 'drift_base': -0.012, 'weight': 5},
}

# Growth floor augmentation (FIX-AI): positive drift at low NDVI.
# Without this, PySR can discover ODEs that are always-negative.
# Ecologically: bare soil with ANY water/light input must grow.
FLOOR_CONFIG = {
    'Rajasthan Canal': {'ndvi_points': [0.05, 0.08, 0.10, 0.12, 0.15], 'drift_base': 0.020, 'weight': 5},
    'Gobi Green Wall': {'ndvi_points': [0.02, 0.03, 0.04, 0.05, 0.06], 'drift_base': 0.008, 'weight': 5},
}

# ============================================================
# Physical Direction Metadata  (FIX-AA)
# ============================================================
# physical_good: +1 = increasing this variable helps vegetation growth
#                -1 = increasing this variable hurts vegetation growth
# lever_role:    'direct' = valid intervention lever
#                'diagnostic_only' = state variable or derived, not a lever
VARIABLE_META = {
    'NDVI':              {'physical_good': +1, 'lever_role': 'diagnostic_only',
                          'description': 'state variable, not a lever'},
    'NDVI_sq':           {'physical_good': +1, 'lever_role': 'diagnostic_only'},
    'NDVI_logistic':     {'physical_good': +1, 'lever_role': 'diagnostic_only'},
    'Rain_norm':         {'physical_good': +1, 'lever_role': 'direct',
                          'description': 'rainfall — more helps vegetation'},
    'SoilMoist':         {'physical_good': +1, 'lever_role': 'direct',
                          'description': 'soil water — more helps vegetation'},
    'FPAR':              {'physical_good': +1, 'lever_role': 'direct',
                          'description': 'canopy light use — more = healthier'},
    'Dust_Stress':       {'physical_good': -1, 'lever_role': 'direct',
                          'description': 'dust/aerosol load — less is better'},
    'Fire_Pressure':     {'physical_good': -1, 'lever_role': 'direct',
                          'description': 'fire disturbance — less is better'},
    'Carbon_Flux':       {'physical_good': +1, 'lever_role': 'direct'},
    'Albedo':            {'physical_good': -1, 'lever_role': 'direct',
                          'description': 'surface reflectance — lower = more vegetation'},
    'LST_Day_anom':      {'physical_good': -1, 'lever_role': 'direct',
                          'description': 'heat anomaly — lower is better'},
    'Temp_Delta_anom':   {'physical_good': -1, 'lever_role': 'direct'},
    'GPP':               {'physical_good': +1, 'lever_role': 'direct'},
    'Groundwater_Anomaly': {'physical_good': +1, 'lever_role': 'direct'},
    # FIX-AA: Aridity_safe is DERIVED = Rain_norm/(NDVI+0.10).
    # It is an outcome of rainfall and vegetation state, not an independent cause.
    # Including it as a lever double-counts the rainfall effect and produces
    # unphysical interventions (you cannot manipulate the ratio independently).
    'Aridity_safe':      {'physical_good': -1, 'lever_role': 'diagnostic_only',
                          'derived_from': ['Rain_norm', 'NDVI'],
                          'description': 'DERIVED: Rain_norm/(NDVI+0.10) — '
                                         'diagnostic only, NOT a valid lever'},
}

# ============================================================
# Feature Sets  (FIX-AG: NDVI_logistic intentionally excluded)
# ============================================================
# NDVI_logistic is computed in build_features for FIX-AE post-hoc
# injection but is NOT included in the PySR feature set because
# its correlation with dNDVI/dt is negative in both regions
# (r ≈ -0.39 Rajasthan, r ≈ -0.69 Gobi), making PySR treat it
# as a negatively-correlated noise feature.
#
# FIX-AA+: Aridity_safe removed from FEATURES because it is derived
# (Rain_norm/(NDVI+0.1)). Using it prevents the intervention engine
# (which modifies Rain_norm) from having any physical effect on the ODE.
FEATURES = [
    'NDVI', 'NDVI_sq',
    'Rain_norm', 'SoilMoist',
    'LST_Day_anom', 'Temp_Delta_anom',
    'Albedo', 'Carbon_Flux', 'FPAR', 'GPP',
    'Dust_Stress', 'Fire_Pressure',
    'Groundwater_Anomaly',
]

# NDVI-like features that must be recomputed dynamically during simulation
# (they depend on the current NDVI state, not fixed driver values)
NDVI_DERIVED_FEATURES = {'NDVI', 'NDVI_sq', 'NDVI_logistic'}

LOW_CORR_THRESHOLD = 0.05
# Region-specific correlation gates (absolute correlation with NDVI).
LOW_CORR_THRESHOLD_BY_REGION = {
  'Rajasthan Canal': 0.08,
  'Gobi Green Wall': 0.05,
}
FLAT_THRESHOLD = 0.50     # FIX-AI: drop features with > 50% identical values
ZERO_FRAC_THRESHOLD = 0.85  # Drop features with > 85% exact zeros (sparse artefacts)

# Rajasthan feature cap to reduce equation complexity.
RAJASTHAN_MAX_FEATURES = 8

# Diagnostics: number of equations to evaluate for summary metrics.
DIAGNOSTIC_EQ_LIMIT = 30

# Reliability acceptance thresholds (report-facing quality gates)
RELIABILITY_MIN_R2 = 0.10
# Rajasthan fit floors to avoid low-fit equilibrium picks.
RAJASTHAN_P1_MIN_R2 = 0.03
RAJASTHAN_P2_MIN_R2 = 0.03
RELIABILITY_MAX_TIER = 3
RELIABILITY_MAX_CLIP_SAT = 0.25
# Low-variance safeguard: allow good absolute fit when R^2 is unstable/negative.
# nMAE is scaled by IQR of deseasonalised target (smaller is better).
RELIABILITY_MAX_NMAE_IQR = 0.90
# Relaxed fallback acceptance: if an equation is in P4/P5 but numerically stable
# and fit is acceptable, allow it for interim reporting.
RELIABILITY_RELAXED_MAX_TIER = 5

# ============================================================
# Simulation Constants
# ============================================================
THRESH = 0.10             # Collapse threshold (NDVI below this = desert)
YEARS  = 50               # Forecast horizon
DT     = 0.1              # Timestep in years (≈ monthly)
N_SIMS = 150              # Monte Carlo ensemble size
FORECAST_START = 2024.0   # Start year for projections

# Stochastic simulation noise calibration (Issue 4: collapse realism)
# Raw std of NDVI differences can overreact to outliers and inflate collapse odds.
# We blend robust estimators and cap per-region sigma used by Euler-Maruyama.
NOISE_CALIBRATION_SCALE = 0.70
NOISE_MIN_SIGMA = 0.0025
NOISE_MAX_SIGMA_DEFAULT = 0.015
NOISE_MAX_SIGMA_BY_REGION = {
  'Rajasthan Canal': 0.018,
  'Gobi Green Wall': 0.012,
}
NOISE_REGION_MULTIPLIER = {
  'Rajasthan Canal': 1.00,
  'Gobi Green Wall': 0.85,
}

# K-shift translation moderation (prevents deterministic 0%/100% saturation).
K_SHIFT_TRANSLATION_GAIN_DEFAULT = 0.75
K_SHIFT_TRANSLATION_GAIN_BY_REGION = {
  'Rajasthan Canal': 0.55,
  'Gobi Green Wall': 0.80,
}
K_SHIFT_TRANSLATION_CLIP = 0.10

# Mild stochastic driver variability during simulation (process realism).
SIM_DRIVER_NOISE_REL = {
  'Rain_norm': 0.05,
  'SoilMoist': 0.04,
  'FPAR': 0.03,
}
SIM_DRIVER_NOISE_MIN_ABS = {
  'Rain_norm': 0.010,
  'SoilMoist': 0.003,
  'FPAR': 0.005,
}
SIM_DRIVER_NOISE_REGION_SCALE = {
  'Rajasthan Canal': 1.20,
  'Gobi Green Wall': 0.90,
}
